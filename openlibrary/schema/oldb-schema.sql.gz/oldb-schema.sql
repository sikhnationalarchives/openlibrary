--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: get_olid(text); Type: FUNCTION; Schema: public; Owner: vagrant
--

CREATE FUNCTION get_olid(text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $_$
        select regexp_replace($1, '.*(OL[0-9]+[A-Z])', E'\1') where $1 ~ '^/.*/OL[0-9]+[A-Z]$';
    $_$;


ALTER FUNCTION public.get_olid(text) OWNER TO vagrant;

--
-- Name: get_property_name(integer, integer); Type: FUNCTION; Schema: public; Owner: vagrant
--

CREATE FUNCTION get_property_name(integer, integer) RETURNS text
    LANGUAGE sql
    AS $_$select property.name FROM property, thing WHERE thing.type = property.type AND thing.id=$1 AND property.id=$2;$_$;


ALTER FUNCTION public.get_property_name(integer, integer) OWNER TO vagrant;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE account (
    thing_id integer,
    email text,
    password text,
    active boolean DEFAULT true,
    bot boolean DEFAULT false,
    verified boolean DEFAULT false
);


ALTER TABLE public.account OWNER TO vagrant;

--
-- Name: author_boolean; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE author_boolean (
    thing_id integer,
    key_id integer,
    value boolean,
    ordering integer
);


ALTER TABLE public.author_boolean OWNER TO vagrant;

--
-- Name: author_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE author_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.author_int OWNER TO vagrant;

--
-- Name: author_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE author_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.author_ref OWNER TO vagrant;

--
-- Name: author_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE author_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.author_str OWNER TO vagrant;

--
-- Name: data; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE data (
    thing_id integer,
    revision integer,
    data text
);


ALTER TABLE public.data OWNER TO vagrant;

--
-- Name: datum_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE datum_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.datum_int OWNER TO vagrant;

--
-- Name: datum_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE datum_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.datum_ref OWNER TO vagrant;

--
-- Name: datum_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE datum_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.datum_str OWNER TO vagrant;

--
-- Name: edition_boolean; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE edition_boolean (
    thing_id integer,
    key_id integer,
    value boolean,
    ordering integer
);


ALTER TABLE public.edition_boolean OWNER TO vagrant;

--
-- Name: edition_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE edition_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.edition_int OWNER TO vagrant;

--
-- Name: edition_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE edition_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.edition_ref OWNER TO vagrant;

--
-- Name: edition_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE edition_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.edition_str OWNER TO vagrant;

--
-- Name: meta; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE meta (
    version integer
);


ALTER TABLE public.meta OWNER TO vagrant;

--
-- Name: property; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE property (
    id integer NOT NULL,
    type integer,
    name text
);


ALTER TABLE public.property OWNER TO vagrant;

--
-- Name: property_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE property_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.property_id_seq OWNER TO vagrant;

--
-- Name: property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE property_id_seq OWNED BY property.id;


--
-- Name: publisher_boolean; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE publisher_boolean (
    thing_id integer,
    key_id integer,
    value boolean,
    ordering integer
);


ALTER TABLE public.publisher_boolean OWNER TO vagrant;

--
-- Name: publisher_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE publisher_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.publisher_int OWNER TO vagrant;

--
-- Name: publisher_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE publisher_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.publisher_ref OWNER TO vagrant;

--
-- Name: publisher_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE publisher_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.publisher_str OWNER TO vagrant;

--
-- Name: scan_boolean; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE scan_boolean (
    thing_id integer,
    key_id integer,
    value boolean,
    ordering integer
);


ALTER TABLE public.scan_boolean OWNER TO vagrant;

--
-- Name: scan_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE scan_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.scan_int OWNER TO vagrant;

--
-- Name: scan_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE scan_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.scan_ref OWNER TO vagrant;

--
-- Name: scan_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE scan_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.scan_str OWNER TO vagrant;

--
-- Name: seq; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE seq (
    id integer NOT NULL,
    name text,
    value integer DEFAULT 0
);


ALTER TABLE public.seq OWNER TO vagrant;

--
-- Name: seq_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE seq_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_id_seq OWNER TO vagrant;

--
-- Name: seq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE seq_id_seq OWNED BY seq.id;


--
-- Name: store; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE store (
    id integer NOT NULL,
    key text,
    json text
);


ALTER TABLE public.store OWNER TO vagrant;

--
-- Name: store_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE store_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_id_seq OWNER TO vagrant;

--
-- Name: store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE store_id_seq OWNED BY store.id;


--
-- Name: store_index; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE store_index (
    id integer NOT NULL,
    store_id integer,
    type text,
    name text,
    value text
);


ALTER TABLE public.store_index OWNER TO vagrant;

--
-- Name: store_index_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE store_index_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_index_id_seq OWNER TO vagrant;

--
-- Name: store_index_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE store_index_id_seq OWNED BY store_index.id;


--
-- Name: subject_boolean; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE subject_boolean (
    thing_id integer,
    key_id integer,
    value boolean,
    ordering integer
);


ALTER TABLE public.subject_boolean OWNER TO vagrant;

--
-- Name: subject_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE subject_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.subject_int OWNER TO vagrant;

--
-- Name: subject_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE subject_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.subject_ref OWNER TO vagrant;

--
-- Name: subject_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE subject_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.subject_str OWNER TO vagrant;

--
-- Name: thing; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE thing (
    id integer NOT NULL,
    key text,
    type integer,
    latest_revision integer DEFAULT 1,
    created timestamp without time zone DEFAULT timezone('utc'::text, now()),
    last_modified timestamp without time zone DEFAULT timezone('utc'::text, now())
);


ALTER TABLE public.thing OWNER TO vagrant;

--
-- Name: thing_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE thing_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.thing_id_seq OWNER TO vagrant;

--
-- Name: thing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE thing_id_seq OWNED BY thing.id;


--
-- Name: transaction; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE transaction (
    id integer NOT NULL,
    action character varying(256),
    author_id integer,
    ip inet,
    comment text,
    bot boolean DEFAULT false,
    created timestamp without time zone DEFAULT timezone('utc'::text, now()),
    changes text,
    data text
);


ALTER TABLE public.transaction OWNER TO vagrant;

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_id_seq OWNER TO vagrant;

--
-- Name: transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE transaction_id_seq OWNED BY transaction.id;


--
-- Name: transaction_index; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE transaction_index (
    tx_id integer,
    key text,
    value text
);


ALTER TABLE public.transaction_index OWNER TO vagrant;

--
-- Name: type_author_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE type_author_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_author_seq OWNER TO vagrant;

--
-- Name: type_edition_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE type_edition_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_edition_seq OWNER TO vagrant;

--
-- Name: type_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE type_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.type_int OWNER TO vagrant;

--
-- Name: type_publisher_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE type_publisher_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_publisher_seq OWNER TO vagrant;

--
-- Name: type_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE type_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.type_ref OWNER TO vagrant;

--
-- Name: type_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE type_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.type_str OWNER TO vagrant;

--
-- Name: type_work_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE type_work_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_work_seq OWNER TO vagrant;

--
-- Name: user_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE user_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.user_int OWNER TO vagrant;

--
-- Name: user_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE user_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.user_ref OWNER TO vagrant;

--
-- Name: user_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE user_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.user_str OWNER TO vagrant;

--
-- Name: version; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE version (
    id integer NOT NULL,
    thing_id integer,
    revision integer,
    transaction_id integer
);


ALTER TABLE public.version OWNER TO vagrant;

--
-- Name: version_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_id_seq OWNER TO vagrant;

--
-- Name: version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE version_id_seq OWNED BY version.id;


--
-- Name: work_boolean; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE work_boolean (
    thing_id integer,
    key_id integer,
    value boolean,
    ordering integer
);


ALTER TABLE public.work_boolean OWNER TO vagrant;

--
-- Name: work_int; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE work_int (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.work_int OWNER TO vagrant;

--
-- Name: work_ref; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE work_ref (
    thing_id integer,
    key_id integer,
    value integer,
    ordering integer
);


ALTER TABLE public.work_ref OWNER TO vagrant;

--
-- Name: work_str; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE work_str (
    thing_id integer,
    key_id integer,
    value character varying(2048),
    ordering integer
);


ALTER TABLE public.work_str OWNER TO vagrant;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY property ALTER COLUMN id SET DEFAULT nextval('property_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY seq ALTER COLUMN id SET DEFAULT nextval('seq_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY store ALTER COLUMN id SET DEFAULT nextval('store_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY store_index ALTER COLUMN id SET DEFAULT nextval('store_index_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY thing ALTER COLUMN id SET DEFAULT nextval('thing_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY transaction ALTER COLUMN id SET DEFAULT nextval('transaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY version ALTER COLUMN id SET DEFAULT nextval('version_id_seq'::regclass);


--
-- Name: account_email_key; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT account_email_key UNIQUE (email);


--
-- Name: property_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY property
    ADD CONSTRAINT property_pkey PRIMARY KEY (id);


--
-- Name: property_type_name_key; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY property
    ADD CONSTRAINT property_type_name_key UNIQUE (type, name);


--
-- Name: seq_name_key; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY seq
    ADD CONSTRAINT seq_name_key UNIQUE (name);


--
-- Name: seq_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY seq
    ADD CONSTRAINT seq_pkey PRIMARY KEY (id);


--
-- Name: store_index_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY store_index
    ADD CONSTRAINT store_index_pkey PRIMARY KEY (id);


--
-- Name: store_key_key; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY store
    ADD CONSTRAINT store_key_key UNIQUE (key);


--
-- Name: store_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY store
    ADD CONSTRAINT store_pkey PRIMARY KEY (id);


--
-- Name: thing_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY thing
    ADD CONSTRAINT thing_pkey PRIMARY KEY (id);


--
-- Name: transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (id);


--
-- Name: version_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY version
    ADD CONSTRAINT version_pkey PRIMARY KEY (id);


--
-- Name: version_thing_id_revision_key; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY version
    ADD CONSTRAINT version_thing_id_revision_key UNIQUE (thing_id, revision);


--
-- Name: account_thing_active_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX account_thing_active_idx ON account USING btree (active);


--
-- Name: account_thing_bot_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX account_thing_bot_idx ON account USING btree (bot);


--
-- Name: account_thing_email_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX account_thing_email_idx ON account USING btree (active);


--
-- Name: account_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX account_thing_id_idx ON account USING btree (thing_id);


--
-- Name: author_boolean_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX author_boolean_idx ON author_boolean USING btree (key_id, value);


--
-- Name: author_boolean_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX author_boolean_thing_id_idx ON author_boolean USING btree (thing_id);


--
-- Name: author_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX author_int_idx ON author_int USING btree (key_id, value);


--
-- Name: author_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX author_int_thing_id_idx ON author_int USING btree (thing_id);


--
-- Name: author_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX author_ref_idx ON author_ref USING btree (key_id, value);


--
-- Name: author_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX author_ref_thing_id_idx ON author_ref USING btree (thing_id);


--
-- Name: author_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX author_str_idx ON author_str USING btree (key_id, value);


--
-- Name: author_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX author_str_thing_id_idx ON author_str USING btree (thing_id);


--
-- Name: data_thing_id_revision_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE UNIQUE INDEX data_thing_id_revision_idx ON data USING btree (thing_id, revision);


--
-- Name: datum_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX datum_int_idx ON datum_int USING btree (key_id, value);


--
-- Name: datum_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX datum_int_thing_id_idx ON datum_int USING btree (thing_id);


--
-- Name: datum_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX datum_ref_idx ON datum_ref USING btree (key_id, value);


--
-- Name: datum_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX datum_ref_thing_id_idx ON datum_ref USING btree (thing_id);


--
-- Name: datum_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX datum_str_idx ON datum_str USING btree (key_id, value);


--
-- Name: datum_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX datum_str_thing_id_idx ON datum_str USING btree (thing_id);


--
-- Name: edition_boolean_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX edition_boolean_idx ON edition_boolean USING btree (key_id, value);


--
-- Name: edition_boolean_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX edition_boolean_thing_id_idx ON edition_boolean USING btree (thing_id);


--
-- Name: edition_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX edition_int_idx ON edition_int USING btree (key_id, value);


--
-- Name: edition_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX edition_int_thing_id_idx ON edition_int USING btree (thing_id);


--
-- Name: edition_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX edition_ref_idx ON edition_ref USING btree (key_id, value);


--
-- Name: edition_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX edition_ref_thing_id_idx ON edition_ref USING btree (thing_id);


--
-- Name: edition_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX edition_str_idx ON edition_str USING btree (key_id, value);


--
-- Name: edition_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX edition_str_thing_id_idx ON edition_str USING btree (thing_id);


--
-- Name: publisher_boolean_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX publisher_boolean_idx ON publisher_boolean USING btree (key_id, value);


--
-- Name: publisher_boolean_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX publisher_boolean_thing_id_idx ON publisher_boolean USING btree (thing_id);


--
-- Name: publisher_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX publisher_int_idx ON publisher_int USING btree (key_id, value);


--
-- Name: publisher_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX publisher_int_thing_id_idx ON publisher_int USING btree (thing_id);


--
-- Name: publisher_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX publisher_ref_idx ON publisher_ref USING btree (key_id, value);


--
-- Name: publisher_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX publisher_ref_thing_id_idx ON publisher_ref USING btree (thing_id);


--
-- Name: publisher_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX publisher_str_idx ON publisher_str USING btree (key_id, value);


--
-- Name: publisher_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX publisher_str_thing_id_idx ON publisher_str USING btree (thing_id);


--
-- Name: scan_boolean_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX scan_boolean_idx ON scan_boolean USING btree (key_id, value);


--
-- Name: scan_boolean_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX scan_boolean_thing_id_idx ON scan_boolean USING btree (thing_id);


--
-- Name: scan_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX scan_int_idx ON scan_int USING btree (key_id, value);


--
-- Name: scan_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX scan_int_thing_id_idx ON scan_int USING btree (thing_id);


--
-- Name: scan_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX scan_ref_idx ON scan_ref USING btree (key_id, value);


--
-- Name: scan_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX scan_ref_thing_id_idx ON scan_ref USING btree (thing_id);


--
-- Name: scan_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX scan_str_idx ON scan_str USING btree (key_id, value);


--
-- Name: scan_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX scan_str_thing_id_idx ON scan_str USING btree (thing_id);


--
-- Name: store_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX store_idx ON store_index USING btree (type, name, value);


--
-- Name: store_index_store_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX store_index_store_id_idx ON store_index USING btree (store_id);


--
-- Name: subject_boolean_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX subject_boolean_idx ON subject_boolean USING btree (key_id, value);


--
-- Name: subject_boolean_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX subject_boolean_thing_id_idx ON subject_boolean USING btree (thing_id);


--
-- Name: subject_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX subject_int_idx ON subject_int USING btree (key_id, value);


--
-- Name: subject_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX subject_int_thing_id_idx ON subject_int USING btree (thing_id);


--
-- Name: subject_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX subject_ref_idx ON subject_ref USING btree (key_id, value);


--
-- Name: subject_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX subject_ref_thing_id_idx ON subject_ref USING btree (thing_id);


--
-- Name: subject_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX subject_str_idx ON subject_str USING btree (key_id, value);


--
-- Name: subject_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX subject_str_thing_id_idx ON subject_str USING btree (thing_id);


--
-- Name: thing_created_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX thing_created_idx ON thing USING btree (created);


--
-- Name: thing_key_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE UNIQUE INDEX thing_key_idx ON thing USING btree (key);


--
-- Name: thing_last_modified_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX thing_last_modified_idx ON thing USING btree (last_modified);


--
-- Name: thing_latest_revision_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX thing_latest_revision_idx ON thing USING btree (latest_revision);


--
-- Name: thing_olid_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX thing_olid_idx ON thing USING btree (get_olid(key));


--
-- Name: thing_type_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX thing_type_idx ON thing USING btree (type);


--
-- Name: transaction_author_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX transaction_author_id_idx ON transaction USING btree (author_id);


--
-- Name: transaction_created_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX transaction_created_idx ON transaction USING btree (created);


--
-- Name: transaction_index_key_value_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX transaction_index_key_value_idx ON transaction_index USING btree (key, value);


--
-- Name: transaction_index_tx_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX transaction_index_tx_id_idx ON transaction_index USING btree (tx_id);


--
-- Name: transaction_ip_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX transaction_ip_idx ON transaction USING btree (ip);


--
-- Name: type_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX type_int_idx ON type_int USING btree (key_id, value);


--
-- Name: type_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX type_int_thing_id_idx ON type_int USING btree (thing_id);


--
-- Name: type_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX type_ref_idx ON type_ref USING btree (key_id, value);


--
-- Name: type_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX type_ref_thing_id_idx ON type_ref USING btree (thing_id);


--
-- Name: type_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX type_str_idx ON type_str USING btree (key_id, value);


--
-- Name: type_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX type_str_thing_id_idx ON type_str USING btree (thing_id);


--
-- Name: user_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX user_int_idx ON user_int USING btree (key_id, value);


--
-- Name: user_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX user_int_thing_id_idx ON user_int USING btree (thing_id);


--
-- Name: user_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX user_ref_idx ON user_ref USING btree (key_id, value);


--
-- Name: user_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX user_ref_thing_id_idx ON user_ref USING btree (thing_id);


--
-- Name: user_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX user_str_idx ON user_str USING btree (key_id, value);


--
-- Name: user_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX user_str_thing_id_idx ON user_str USING btree (thing_id);


--
-- Name: work_boolean_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX work_boolean_idx ON work_boolean USING btree (key_id, value);


--
-- Name: work_boolean_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX work_boolean_thing_id_idx ON work_boolean USING btree (thing_id);


--
-- Name: work_int_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX work_int_idx ON work_int USING btree (key_id, value);


--
-- Name: work_int_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX work_int_thing_id_idx ON work_int USING btree (thing_id);


--
-- Name: work_ref_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX work_ref_idx ON work_ref USING btree (key_id, value);


--
-- Name: work_ref_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX work_ref_thing_id_idx ON work_ref USING btree (thing_id);


--
-- Name: work_str_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX work_str_idx ON work_str USING btree (key_id, value);


--
-- Name: work_str_thing_id_idx; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX work_str_thing_id_idx ON work_str USING btree (thing_id);


--
-- Name: account_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY account
    ADD CONSTRAINT account_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: author_boolean_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_boolean
    ADD CONSTRAINT author_boolean_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: author_boolean_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_boolean
    ADD CONSTRAINT author_boolean_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: author_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_int
    ADD CONSTRAINT author_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: author_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_int
    ADD CONSTRAINT author_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: author_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_ref
    ADD CONSTRAINT author_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: author_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_ref
    ADD CONSTRAINT author_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: author_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_ref
    ADD CONSTRAINT author_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: author_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_str
    ADD CONSTRAINT author_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: author_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY author_str
    ADD CONSTRAINT author_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: data_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY data
    ADD CONSTRAINT data_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: datum_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY datum_int
    ADD CONSTRAINT datum_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: datum_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY datum_int
    ADD CONSTRAINT datum_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: datum_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY datum_ref
    ADD CONSTRAINT datum_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: datum_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY datum_ref
    ADD CONSTRAINT datum_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: datum_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY datum_ref
    ADD CONSTRAINT datum_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: datum_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY datum_str
    ADD CONSTRAINT datum_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: datum_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY datum_str
    ADD CONSTRAINT datum_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: edition_boolean_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_boolean
    ADD CONSTRAINT edition_boolean_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: edition_boolean_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_boolean
    ADD CONSTRAINT edition_boolean_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: edition_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_int
    ADD CONSTRAINT edition_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: edition_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_int
    ADD CONSTRAINT edition_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: edition_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_ref
    ADD CONSTRAINT edition_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: edition_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_ref
    ADD CONSTRAINT edition_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: edition_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_ref
    ADD CONSTRAINT edition_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: edition_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_str
    ADD CONSTRAINT edition_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: edition_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY edition_str
    ADD CONSTRAINT edition_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: property_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY property
    ADD CONSTRAINT property_type_fkey FOREIGN KEY (type) REFERENCES thing(id);


--
-- Name: publisher_boolean_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_boolean
    ADD CONSTRAINT publisher_boolean_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: publisher_boolean_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_boolean
    ADD CONSTRAINT publisher_boolean_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: publisher_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_int
    ADD CONSTRAINT publisher_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: publisher_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_int
    ADD CONSTRAINT publisher_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: publisher_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_ref
    ADD CONSTRAINT publisher_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: publisher_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_ref
    ADD CONSTRAINT publisher_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: publisher_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_ref
    ADD CONSTRAINT publisher_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: publisher_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_str
    ADD CONSTRAINT publisher_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: publisher_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY publisher_str
    ADD CONSTRAINT publisher_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: scan_boolean_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_boolean
    ADD CONSTRAINT scan_boolean_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: scan_boolean_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_boolean
    ADD CONSTRAINT scan_boolean_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: scan_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_int
    ADD CONSTRAINT scan_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: scan_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_int
    ADD CONSTRAINT scan_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: scan_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_ref
    ADD CONSTRAINT scan_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: scan_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_ref
    ADD CONSTRAINT scan_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: scan_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_ref
    ADD CONSTRAINT scan_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: scan_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_str
    ADD CONSTRAINT scan_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: scan_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY scan_str
    ADD CONSTRAINT scan_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: store_index_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY store_index
    ADD CONSTRAINT store_index_store_id_fkey FOREIGN KEY (store_id) REFERENCES store(id);


--
-- Name: subject_boolean_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_boolean
    ADD CONSTRAINT subject_boolean_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: subject_boolean_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_boolean
    ADD CONSTRAINT subject_boolean_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: subject_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_int
    ADD CONSTRAINT subject_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: subject_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_int
    ADD CONSTRAINT subject_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: subject_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_ref
    ADD CONSTRAINT subject_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: subject_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_ref
    ADD CONSTRAINT subject_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: subject_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_ref
    ADD CONSTRAINT subject_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: subject_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_str
    ADD CONSTRAINT subject_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: subject_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY subject_str
    ADD CONSTRAINT subject_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: thing_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY thing
    ADD CONSTRAINT thing_type_fkey FOREIGN KEY (type) REFERENCES thing(id);


--
-- Name: transaction_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY transaction
    ADD CONSTRAINT transaction_author_id_fkey FOREIGN KEY (author_id) REFERENCES thing(id);


--
-- Name: transaction_index_tx_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY transaction_index
    ADD CONSTRAINT transaction_index_tx_id_fkey FOREIGN KEY (tx_id) REFERENCES transaction(id);


--
-- Name: type_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY type_int
    ADD CONSTRAINT type_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: type_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY type_int
    ADD CONSTRAINT type_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: type_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY type_ref
    ADD CONSTRAINT type_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: type_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY type_ref
    ADD CONSTRAINT type_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: type_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY type_ref
    ADD CONSTRAINT type_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: type_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY type_str
    ADD CONSTRAINT type_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: type_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY type_str
    ADD CONSTRAINT type_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: user_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY user_int
    ADD CONSTRAINT user_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: user_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY user_int
    ADD CONSTRAINT user_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: user_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY user_ref
    ADD CONSTRAINT user_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: user_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY user_ref
    ADD CONSTRAINT user_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: user_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY user_ref
    ADD CONSTRAINT user_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: user_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY user_str
    ADD CONSTRAINT user_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: user_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY user_str
    ADD CONSTRAINT user_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: version_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY version
    ADD CONSTRAINT version_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: version_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY version
    ADD CONSTRAINT version_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES transaction(id);


--
-- Name: work_boolean_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_boolean
    ADD CONSTRAINT work_boolean_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: work_boolean_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_boolean
    ADD CONSTRAINT work_boolean_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: work_int_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_int
    ADD CONSTRAINT work_int_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: work_int_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_int
    ADD CONSTRAINT work_int_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: work_ref_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_ref
    ADD CONSTRAINT work_ref_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: work_ref_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_ref
    ADD CONSTRAINT work_ref_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: work_ref_value_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_ref
    ADD CONSTRAINT work_ref_value_fkey FOREIGN KEY (value) REFERENCES thing(id);


--
-- Name: work_str_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_str
    ADD CONSTRAINT work_str_key_id_fkey FOREIGN KEY (key_id) REFERENCES property(id);


--
-- Name: work_str_thing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY work_str
    ADD CONSTRAINT work_str_thing_id_fkey FOREIGN KEY (thing_id) REFERENCES thing(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

